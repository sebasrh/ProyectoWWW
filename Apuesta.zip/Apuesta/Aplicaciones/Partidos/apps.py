from django.apps import AppConfig


class PartidosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Aplicaciones.Partidos'
